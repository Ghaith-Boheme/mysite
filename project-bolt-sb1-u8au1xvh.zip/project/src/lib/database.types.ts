export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          full_name: string | null
          bio: string | null
          avatar_url: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          full_name?: string | null
          bio?: string | null
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          full_name?: string | null
          bio?: string | null
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      experiences: {
        Row: {
          id: string
          title: string
          company: string
          start_date: string
          end_date: string | null
          description: string | null
          order_index: number
          created_at: string
        }
        Insert: {
          id?: string
          title: string
          company: string
          start_date: string
          end_date?: string | null
          description?: string | null
          order_index?: number
          created_at?: string
        }
        Update: {
          id?: string
          title?: string
          company?: string
          start_date?: string
          end_date?: string | null
          description?: string | null
          order_index?: number
          created_at?: string
        }
      }
      skills: {
        Row: {
          id: string
          name: string
          category: string
          proficiency: number
          order_index: number
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          category: string
          proficiency: number
          order_index?: number
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          category?: string
          proficiency?: number
          order_index?: number
          created_at?: string
        }
      }
      journal_entries: {
        Row: {
          id: string
          title: string
          content: string
          category: string | null
          is_published: boolean
          author_id: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          content: string
          category?: string | null
          is_published?: boolean
          author_id: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          content?: string
          category?: string | null
          is_published?: boolean
          author_id?: string
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}