import React from 'react';
import { motion } from 'framer-motion';
import {
  Users,
  MessageSquare,
  Eye,
  ArrowUp,
  ArrowDown,
  Activity,
  Globe,
  Clock
} from 'lucide-react';

export function Dashboard() {
  const stats = [
    {
      title: 'إجمالي المستخدمين',
      value: '1,234',
      change: '+12%',
      isPositive: true,
      icon: Users
    },
    {
      title: 'الرسائل الجديدة',
      value: '56',
      change: '+23%',
      isPositive: true,
      icon: MessageSquare
    },
    {
      title: 'المشاهدات',
      value: '89,012',
      change: '-5%',
      isPositive: false,
      icon: Eye
    },
    {
      title: 'معدل التفاعل',
      value: '67%',
      change: '+8%',
      isPositive: true,
      icon: Activity
    }
  ];

  const recentActivities = [
    {
      user: 'أحمد محمد',
      action: 'قام بتسجيل حساب جديد',
      time: 'منذ 5 دقائق'
    },
    {
      user: 'سارة أحمد',
      action: 'أرسلت رسالة جديدة',
      time: 'منذ 15 دقيقة'
    },
    {
      user: 'محمد علي',
      action: 'قام بتحديث ملفه الشخصي',
      time: 'منذ ساعة'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg"
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-500 dark:text-gray-400">{stat.title}</p>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                  {stat.value}
                </h3>
              </div>
              <div className={`p-3 rounded-full ${
                stat.isPositive ? 'bg-green-100 dark:bg-green-900/30' : 'bg-red-100 dark:bg-red-900/30'
              }`}>
                <stat.icon className={`w-6 h-6 ${
                  stat.isPositive ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                }`} />
              </div>
            </div>
            <div className="flex items-center mt-4">
              {stat.isPositive ? (
                <ArrowUp className="w-4 h-4 text-green-500" />
              ) : (
                <ArrowDown className="w-4 h-4 text-red-500" />
              )}
              <span className={`text-sm ml-1 ${
                stat.isPositive ? 'text-green-500' : 'text-red-500'
              }`}>
                {stat.change}
              </span>
              <span className="text-sm text-gray-500 dark:text-gray-400 mr-2">
                مقارنة بالشهر الماضي
              </span>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activities */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
              النشاطات الأخيرة
            </h2>
            <Clock className="w-5 h-5 text-gray-500 dark:text-gray-400" />
          </div>
          <div className="space-y-4">
            {recentActivities.map((activity, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 rounded-lg bg-gray-50 dark:bg-gray-700/50"
              >
                <div className="flex items-center space-x-3 rtl:space-x-reverse">
                  <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
                    <span className="text-white font-semibold">
                      {activity.user.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">
                      {activity.user}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      {activity.action}
                    </p>
                  </div>
                </div>
                <span className="text-sm text-gray-500 dark:text-gray-400">
                  {activity.time}
                </span>
              </div>
            ))}
          </div>
        </motion.div>

        {/* World Map */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="bg-white dark:bg-gray-800 rounded-xl p-6 shadow-lg"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
              الزوار حول العالم
            </h2>
            <Globe className="w-5 h-5 text-gray-500 dark:text-gray-400" />
          </div>
          <div className="h-[300px] flex items-center justify-center">
            {/* Here you would integrate a world map visualization */}
            <p className="text-gray-500 dark:text-gray-400">خريطة تفاعلية للزوار</p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}