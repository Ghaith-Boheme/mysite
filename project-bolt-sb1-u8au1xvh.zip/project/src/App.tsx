import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { FloatingCode } from './components/FloatingCode';
import { NeuralBackground } from './components/NeuralBackground';
import { Moon, Sun, Languages } from 'lucide-react';
import { AuthProvider, useAuth } from './lib/auth';
import Home from './sections/Home';
import About from './sections/About';
import Projects from './sections/Projects';
import News from './sections/News';
import Gallery from './sections/Gallery';
import Contact from './sections/Contact';
import { ScrollProgress } from './components/ScrollProgress';
import { AdminLayout } from './components/admin/AdminLayout';
import { Dashboard } from './components/admin/Dashboard';
import { Analytics } from './components/admin/Analytics';
import { Login } from './components/admin/Login';
import { PageTransition } from './components/PageTransition';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/admin/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
}

function MainLayout({ isDark, isRTL, setIsDark, setIsRTL }: {
  isDark: boolean;
  isRTL: boolean;
  setIsDark: (value: boolean) => void;
  setIsRTL: (value: boolean) => void;
}) {
  const [activeSection, setActiveSection] = React.useState('home');
  const location = useLocation();

  const sectionRefs = {
    home: React.useRef<HTMLDivElement>(null),
    about: React.useRef<HTMLDivElement>(null),
    projects: React.useRef<HTMLDivElement>(null),
    news: React.useRef<HTMLDivElement>(null),
    gallery: React.useRef<HTMLDivElement>(null),
    contact: React.useRef<HTMLDivElement>(null),
  };

  const scrollToSection = (section: string) => {
    sectionRefs[section as keyof typeof sectionRefs].current?.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
  };

  React.useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + window.innerHeight / 3;

      for (const [section, ref] of Object.entries(sectionRefs)) {
        if (ref.current) {
          const element = ref.current;
          const { top, bottom } = element.getBoundingClientRect();
          const elementMiddle = window.scrollY + top + (bottom - top) / 2;

          if (Math.abs(scrollPosition - elementMiddle) < window.innerHeight / 3) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const bgColor = isDark ? 'bg-gray-900' : 'bg-gray-50';
  const navBgColor = isDark ? 'bg-gray-900/80' : 'bg-white/80';
  const textColor = isDark ? 'text-white' : 'text-gray-900';
  const textColorSecondary = isDark ? 'text-gray-300' : 'text-gray-600';
  const buttonHoverBg = isDark ? 'hover:bg-gray-800' : 'hover:bg-gray-200';

  return (
    <div className={`min-h-screen ${bgColor} transition-colors duration-300`} dir={isRTL ? 'rtl' : 'ltr'}>
      <NeuralBackground isDark={isDark} />
      <FloatingCode isDark={isDark} />
      <ScrollProgress />
      
      <nav className={`fixed top-0 left-0 right-0 z-50 backdrop-blur-sm ${navBgColor} transition-colors duration-300`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <button
                onClick={() => scrollToSection('home')}
                className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-purple-600 text-transparent bg-clip-text"
              >
                {isRTL ? 'المعرض' : 'Portfolio'}
              </button>
              <div className="hidden md:flex space-x-4 rtl:space-x-reverse">
                {Object.keys(sectionRefs).map((section) => (
                  <button
                    key={section}
                    onClick={() => scrollToSection(section)}
                    className={`px-3 py-2 rounded-md transition-all transform hover:scale-105 ${
                      activeSection === section
                        ? isDark ? 'text-white bg-gray-800' : 'text-gray-900 bg-gray-200'
                        : `${textColorSecondary} ${buttonHoverBg}`
                    }`}
                  >
                    {isRTL
                      ? section === 'home'
                        ? 'الرئيسية'
                        : section === 'about'
                        ? 'عني'
                        : section === 'projects'
                        ? 'المشاريع'
                        : section === 'news'
                        ? 'الأخبار'
                        : section === 'gallery'
                        ? 'معرض الصور'
                        : 'اتصل بي'
                      : section.charAt(0).toUpperCase() + section.slice(1)}
                  </button>
                ))}
              </div>
            </div>
            <div className="flex items-center space-x-4 rtl:space-x-reverse">
              <button
                onClick={() => setIsDark(!isDark)}
                className={`p-2 rounded-lg ${buttonHoverBg} transition-all transform hover:scale-110`}
                aria-label={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
              >
                {isDark ? (
                  <Sun className="w-5 h-5 text-yellow-400" />
                ) : (
                  <Moon className="w-5 h-5 text-gray-600" />
                )}
              </button>
              <button
                onClick={() => setIsRTL(!isRTL)}
                className={`p-2 rounded-lg ${buttonHoverBg} transition-all transform hover:scale-110`}
                aria-label={isRTL ? 'Switch to LTR' : 'Switch to RTL'}
              >
                <Languages className="w-5 h-5 text-blue-500" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <PageTransition location={location.pathname}>
        <main className="relative">
          <section ref={sectionRefs.home} className="min-h-screen">
            <Home isRTL={isRTL} isDark={isDark} />
          </section>
          <section ref={sectionRefs.about} className="min-h-screen">
            <About isRTL={isRTL} isDark={isDark} />
          </section>
          <section ref={sectionRefs.projects} className="min-h-screen">
            <Projects isRTL={isRTL} isDark={isDark} />
          </section>
          <section ref={sectionRefs.news} className="min-h-screen">
            <News isRTL={isRTL} isDark={isDark} />
          </section>
          <section ref={sectionRefs.gallery} className="min-h-screen">
            <Gallery isRTL={isRTL} isDark={isDark} />
          </section>
          <section ref={sectionRefs.contact} className="min-h-screen">
            <Contact isRTL={isRTL} isDark={isDark} />
          </section>
        </main>
      </PageTransition>
    </div>
  );
}

function App() {
  const [isDark, setIsDark] = React.useState(true);
  const [isRTL, setIsRTL] = React.useState(true);

  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/admin/login" element={<Login />} />
          <Route
            path="/admin"
            element={
              <ProtectedRoute>
                <AdminLayout currentPage="/admin">
                  <Dashboard />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/admin/analytics"
            element={
              <ProtectedRoute>
                <AdminLayout currentPage="/admin/analytics">
                  <Analytics />
                </AdminLayout>
              </ProtectedRoute>
            }
          />
          <Route
            path="/"
            element={
              <MainLayout
                isDark={isDark}
                isRTL={isRTL}
                setIsDark={setIsDark}
                setIsRTL={setIsRTL}
              />
            }
          />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;