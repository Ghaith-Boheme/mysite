import React, { useEffect, useRef, useState } from 'react';
import { motion, useAnimation, AnimatePresence } from 'framer-motion';
import { Sparkles, Zap, Scan, Maximize2 } from 'lucide-react';

interface FuturisticProfileProps {
  isRTL: boolean;
  isDark: boolean;
  imageUrl?: string;
}

export const FuturisticProfile: React.FC<FuturisticProfileProps> = ({ 
  isRTL, 
  isDark,
  imageUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isHovered, setIsHovered] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [scanLine, setScanLine] = useState(0);
  const [dataPoints, setDataPoints] = useState<Array<{x: number, y: number, size: number, color: string}>>([]);
  const controls = useAnimation();

  // Generate random data points for the holographic effect
  useEffect(() => {
    const points = [];
    for (let i = 0; i < 15; i++) {
      points.push({
        x: Math.random() * 100,
        y: Math.random() * 100,
        size: 2 + Math.random() * 5,
        color: `hsl(${180 + Math.random() * 60}, 100%, ${isDark ? 70 : 50}%)`
      });
    }
    setDataPoints(points);
  }, [isDark]);

  // Animate scan line
  useEffect(() => {
    let animationFrame: number;
    let direction = 1;
    let position = 0;

    const animate = () => {
      position += direction * 1.5;
      
      if (position > 100) {
        direction = -1;
      } else if (position < 0) {
        direction = 1;
      }
      
      setScanLine(position);
      animationFrame = requestAnimationFrame(animate);
    };

    if (isHovered) {
      animate();
    }

    return () => {
      if (animationFrame) {
        cancelAnimationFrame(animationFrame);
      }
    };
  }, [isHovered]);

  // Particle effect
  useEffect(() => {
    if (!canvasRef.current || !isHovered) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions
    const updateCanvasSize = () => {
      if (containerRef.current) {
        const { width, height } = containerRef.current.getBoundingClientRect();
        canvas.width = width;
        canvas.height = height;
      }
    };

    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);

    // Create particles
    const particles: Array<{
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      color: string;
      life: number;
      maxLife: number;
    }> = [];

    const createParticle = () => {
      if (containerRef.current) {
        const { width, height } = containerRef.current.getBoundingClientRect();
        
        // Create particles around the edge of the image
        const angle = Math.random() * Math.PI * 2;
        const radius = Math.min(width, height) / 2 * 0.8;
        const x = width / 2 + Math.cos(angle) * radius;
        const y = height / 2 + Math.sin(angle) * radius;
        
        particles.push({
          x,
          y,
          size: 0.5 + Math.random() * 2,
          speedX: (Math.random() - 0.5) * 1,
          speedY: (Math.random() - 0.5) * 1,
          color: `hsl(${180 + Math.random() * 60}, 100%, ${isDark ? 70 : 50}%)`,
          life: 0,
          maxLife: 50 + Math.random() * 100
        });
      }
    };

    // Animation loop
    let animationFrame: number;
    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Add new particles
      if (Math.random() < 0.3) {
        createParticle();
      }
      
      // Update and draw particles
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.life++;
        
        if (p.life >= p.maxLife) {
          particles.splice(i, 1);
          i--;
          continue;
        }
        
        p.x += p.speedX;
        p.y += p.speedY;
        
        // Fade based on life
        const opacity = 1 - p.life / p.maxLife;
        
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color.replace(')', `, ${opacity})`).replace('hsl', 'hsla');
        ctx.fill();
      }
      
      animationFrame = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      window.removeEventListener('resize', updateCanvasSize);
      cancelAnimationFrame(animationFrame);
    };
  }, [isHovered, isDark]);

  // Expand/collapse animation
  const handleExpand = () => {
    setIsExpanded(!isExpanded);
    controls.start({
      scale: isExpanded ? 1 : 1.05,
      transition: { duration: 0.5, type: "spring" }
    });
  };

  // Colors based on theme
  const glowColor = isDark 
    ? "0 0 15px rgba(56, 189, 248, 0.5), 0 0 30px rgba(56, 189, 248, 0.3)" 
    : "0 0 15px rgba(79, 70, 229, 0.3), 0 0 30px rgba(79, 70, 229, 0.2)";
  
  const borderColor = isDark 
    ? "border-cyan-400/30" 
    : "border-indigo-500/30";
  
  const bgGradient = isDark
    ? "bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900"
    : "bg-gradient-to-br from-white via-gray-50 to-white";

  const textColor = isDark ? "text-white" : "text-gray-800";
  const accentColor = isDark ? "text-cyan-400" : "text-indigo-600";

  return (
    <div className="relative flex justify-center items-center py-8">
      <motion.div 
        ref={containerRef}
        className={`relative ${isExpanded ? 'w-full max-w-2xl' : 'w-64 h-64 md:w-80 md:h-80'} overflow-hidden rounded-2xl ${borderColor} border-2 ${bgGradient}`}
        style={{ 
          boxShadow: isHovered ? glowColor : "none",
          transition: "box-shadow 0.5s ease"
        }}
        animate={controls}
        onHoverStart={() => setIsHovered(true)}
        onHoverEnd={() => setIsHovered(false)}
        layout
      >
        {/* Holographic data points */}
        <AnimatePresence>
          {isHovered && dataPoints.map((point, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.7 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="absolute rounded-full"
              style={{
                left: `${point.x}%`,
                top: `${point.y}%`,
                width: `${point.size}px`,
                height: `${point.size}px`,
                backgroundColor: point.color,
                boxShadow: `0 0 5px ${point.color}`,
              }}
            />
          ))}
        </AnimatePresence>

        {/* Scan line */}
        {isHovered && (
          <div 
            className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent z-10"
            style={{ top: `${scanLine}%`, opacity: 0.7 }}
          />
        )}

        {/* Canvas for particle effects */}
        <canvas 
          ref={canvasRef} 
          className="absolute inset-0 pointer-events-none z-20"
        />

        {/* Profile image */}
        <motion.div 
          className={`relative w-full h-full ${isExpanded ? 'aspect-video' : 'aspect-square'}`}
          layout
        >
          <img 
            src="https://j.top4top.io/p_3345winqg1.jpg" 
            alt="Profile"
            className={`w-full h-full object-cover ${isHovered ? 'brightness-110 contrast-110' : ''}`}
            style={{ transition: "filter 0.5s ease" }}
          />

          {/* Holographic overlay */}
          <div 
            className={`absolute inset-0 bg-gradient-to-t ${
              isDark 
                ? 'from-cyan-500/10 via-transparent to-purple-500/10' 
                : 'from-indigo-500/10 via-transparent to-purple-500/10'
            } mix-blend-overlay`}
          />

          {/* Futuristic UI elements */}
          <AnimatePresence>
            {isHovered && (
              <>
                {/* Top left */}
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="absolute top-3 left-3 flex items-center"
                >
                  <Sparkles className={`w-4 h-4 ${accentColor} mr-1`} />
                  <span className={`text-xs font-mono ${accentColor}`}>ID.2090.45X</span>
                </motion.div>

                {/* Top right */}
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.3 }}
                  className="absolute top-3 right-3"
                >
                  <button 
                    onClick={handleExpand}
                    className={`p-1 rounded-full bg-black/20 backdrop-blur-sm ${accentColor} hover:bg-black/40 transition-colors`}
                  >
                    <Maximize2 className="w-4 h-4" />
                  </button>
                </motion.div>

                {/* Bottom left */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                  transition={{ duration: 0.3 }}
                  className="absolute bottom-3 left-3 flex items-center"
                >
                  <Scan className={`w-4 h-4 ${accentColor} mr-1`} />
                  <span className={`text-xs font-mono ${accentColor}`}>SCAN COMPLETE</span>
                </motion.div>

                {/* Bottom right */}
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 20 }}
                  transition={{ duration: 0.3 }}
                  className="absolute bottom-3 right-3 flex items-center"
                >
                  <Zap className={`w-4 h-4 ${accentColor} mr-1`} />
                  <span className={`text-xs font-mono ${accentColor}`}>100%</span>
                </motion.div>
              </>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Expanded content */}
        <AnimatePresence>
          {isExpanded && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.5 }}
              className={`p-4 ${isDark ? 'bg-gray-800/80' : 'bg-white/80'} backdrop-blur-sm`}
            >
              <h3 className={`text-xl font-bold ${textColor} mb-2`}>
                {isRTL ? 'غيث بوهيمي' : 'Ghaith Boheme'}
              </h3>
              <p className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-600'}`}>
                {isRTL 
                  ? 'أبحث عن حلول مبتكرة للمشاكل باستخدام أدوات التكنولوجيا الحديثة والذكاء الاصطناعي، لخلق تجارب عملية تسهم في تحسين الكفاءة وتبسيط الحياة اليومية. أركز على تقديم حلول عميقة تعزز الأداء وتوفر طرقًا أكثر فعالية لأتمتة المهام وتسهيل العمليات.'
                  : 'I seek innovative solutions to problems using modern technology tools and artificial intelligence, creating practical experiences that improve efficiency and simplify daily life. I focus on delivering deep solutions that enhance performance and provide more effective ways to automate tasks and streamline processes.'}
              </p>
              
              <div className="mt-4 flex flex-wrap gap-2">
                {['React', 'TypeScript', 'Node.js', 'UI/UX'].map((skill, index) => (
                  <span 
                    key={index}
                    className={`px-2 py-1 text-xs rounded-full ${
                      isDark 
                        ? 'bg-cyan-900/50 text-cyan-300 border border-cyan-700/50' 
                        : 'bg-indigo-100 text-indigo-700 border border-indigo-200'
                    }`}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
};