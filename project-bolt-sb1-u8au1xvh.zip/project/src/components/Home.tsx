import React from 'react';
import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

interface HomeProps {
  isRTL: boolean;
}

export default function Home({ isRTL }: HomeProps) {
  const { elementRef, isVisible } = useIntersectionObserver();

  return (
    <div ref={elementRef} className="relative min-h-screen flex items-center justify-center px-4 py-16">
      <div className="max-w-4xl mx-auto text-center">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-transparent bg-clip-text"
        >
          {isRTL ? 'مرحباً بك في معرضي' : 'Welcome to My Portfolio'}
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="text-xl md:text-2xl text-gray-300 mb-8"
        >
          {isRTL 
            ? 'مطور برمجيات متخصص في بناء تطبيقات ويب حديثة وتفاعلية'
            : 'A software developer specialized in building modern, interactive web applications'}
        </motion.p>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="flex flex-col items-center"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className="mt-8"
          >
            <ArrowDown className="w-8 h-8 text-blue-400" />
          </motion.div>
        </motion.div>
      </div>
    </div>
  );
}