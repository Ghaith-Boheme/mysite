import React from 'react';
import { motion } from 'framer-motion';
import { Award, Book, Briefcase, Code } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

interface AboutProps {
  isRTL: boolean;
  isDark: boolean;
}

export default function About({ isRTL, isDark }: AboutProps) {
  const { elementRef, isVisible } = useIntersectionObserver();
  
  const skills = [
    { name: 'React', level: 90 },
    { name: 'TypeScript', level: 85 },
    { name: 'Node.js', level: 80 },
    { name: 'Python', level: 75 },
  ];

  // Enhanced colors for light mode
  const textColor = isDark ? 'text-white' : 'text-gray-800';
  const textColorSecondary = isDark ? 'text-gray-300' : 'text-gray-600';
  const cardBg = isDark ? 'bg-gray-800 bg-opacity-50' : 'bg-white shadow-md';
  const iconColor = {
    blue: isDark ? 'text-blue-400' : 'text-blue-600',
    purple: isDark ? 'text-purple-400' : 'text-purple-600',
    yellow: isDark ? 'text-yellow-400' : 'text-yellow-600',
    green: isDark ? 'text-green-400' : 'text-green-600',
  };

  return (
    <div ref={elementRef} className="min-h-screen py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-blue-500 to-purple-600 text-transparent bg-clip-text text-center tracking-tight"
        >
          {isRTL ? 'من أنا' : 'About Me'}
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className={`${cardBg} rounded-xl p-6 mb-8`}
        >
          <div className="flex items-center mb-4">
            <Book className={`w-6 h-6 ${iconColor.blue} mr-2`} />
            <h2 className={`text-2xl font-semibold ${textColor} tracking-tight`}>
              {isRTL ? 'نبذة عني' : 'Bio'}
            </h2>
          </div>
          <div className={`${textColorSecondary} leading-relaxed space-y-4`}>
            {isRTL ? (
              <>
                <p className="font-semibold text-lg">من أنت؟؟؟</p>
                <p className="leading-relaxed">
                  تذكرت إجابة الأديب حمزة شحاتة عندما سُئل هذا السؤال المحير من صحيفة البلاد: "من أنت؟". كانت إجابته كما يذكر:
                </p>
                <p className="italic leading-relaxed text-justify">
                  (من أنا؟ يبدو لي أنني لم أستقبل حياتي منذ وعيت حتى هذه الساعة. كنت أعيش متأثراً بجملة الظروف والدوافع والمقاومات. أسير وأتقهقر وأقف، وأحياناً أعدو بجنون. وحين يتاح لي أن أتأمل ذاتي، أرى أنني أداة تملى عليها مقدرات حركتها وسكونها. لم أشعر قط بتحرير إرادتي. وحين بدا للآخرين أنني اكتملت بحكم السن واتساع أفق التجربة، وجدت أن ما يسمى بالإرادة فينا ليس إلا حاصل ظروف وعوامل ينسحق فيها ما هو ذاتي وداخلي تحت وطأة ما هو خارجي. فإذا قلت الآن بصدق: إنني أجهل من أنا أو ما أنا، فلأنني لم أستقبل قط ما أستطيع أن أسميه حياتي.)
                </p>
                <p className="leading-relaxed">
                  وعندما سألوني: "من أنت؟"، ذهلت. لأنني لم أجد في حياتي كلها ما يعينني على أن أعرف من أنا؟ نعم، وبمزيد من المرارة والخجل والحيرة والضياع: من أنا؟
                </p>
              </>
            ) : (
              <>
                <p className="font-semibold text-lg">Who are you???</p>
                <p className="leading-relaxed">
                  I remembered the answer of the writer Hamza Shahat when he was asked this perplexing question by Al-Bilad newspaper: "Who are you?". His answer, as mentioned, was:
                </p>
                <p className="italic leading-relaxed text-justify">
                  (Who am I? It seems to me that I have never truly embraced my life since I became conscious, up until this moment. I lived, influenced by various circumstances, motives, and resistances. I walk, retreat, stop, and sometimes run recklessly. When I have the chance to reflect on myself, I see that I am an instrument, with its movements and stillness dictated by external forces. I have never felt the freedom of my will. And when others thought I had reached a state of completeness due to age and the expansion of experience, I realized that what we call willpower is merely the result of circumstances and factors where the internal and personal are crushed under the weight of the external. So, if I say now, honestly, that I do not know who I am or what I am, it is because I have never truly received what I can call my life.)
                </p>
                <p className="leading-relaxed">
                  When they asked me, "Who are you?", I was stunned. I found nothing in my life to help me answer that question. Yes, with a deep sense of bitterness, embarrassment, confusion, and loss: who am I?
                </p>
              </>
            )}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="grid md:grid-cols-2 gap-6 mb-8"
        >
          <div className={`${cardBg} rounded-xl p-6`}>
            <div className="flex items-center mb-4">
              <Briefcase className={`w-6 h-6 ${iconColor.purple} mr-2`} />
              <h2 className={`text-2xl font-semibold ${textColor} tracking-tight`}>
                {isRTL ? 'الخبرة' : 'Experience'}
              </h2>
            </div>
            <ul className="space-y-4">
              <li>
                <h3 className={`text-lg font-semibold ${textColor}`}>Senior Developer</h3>
                <p className={`${textColorSecondary} text-sm`}>Tech Corp • 2020 - Present</p>
              </li>
              <li>
                <h3 className={`text-lg font-semibold ${textColor}`}>Full Stack Developer</h3>
                <p className={`${textColorSecondary} text-sm`}>Web Solutions • 2018 - 2020</p>
              </li>
            </ul>
          </div>

          <div className={`${cardBg} rounded-xl p-6`}>
            <div className="flex items-center mb-4">
              <Award className={`w-6 h-6 ${iconColor.yellow} mr-2`} />
              <h2 className={`text-2xl font-semibold ${textColor} tracking-tight`}>
                {isRTL ? 'التعليم' : 'Education'}
              </h2>
            </div>
            <ul className="space-y-4">
              <li>
                <h3 className={`text-lg font-semibold ${textColor}`}>MSc Computer Science</h3>
                <p className={`${textColorSecondary} text-sm`}>Tech University • 2018</p>
              </li>
              <li>
                <h3 className={`text-lg font-semibold ${textColor}`}>BSc Computer Science</h3>
                <p className={`${textColorSecondary} text-sm`}>State University • 2016</p>
              </li>
            </ul>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className={`${cardBg} rounded-xl p-6`}
        >
          <div className="flex items-center mb-6">
            <Code className={`w-6 h-6 ${iconColor.green} mr-2`} />
            <h2 className={`text-2xl font-semibold ${textColor} tracking-tight`}>
              {isRTL ? 'المهارات' : 'Skills'}
            </h2>
          </div>
          <div className="space-y-4">
            {skills.map((skill, index) => (
              <div key={skill.name}>
                <div className="flex justify-between mb-1">
                  <span className={`${textColor} font-medium`}>{skill.name}</span>
                  <span className={`${textColorSecondary} text-sm`}>{skill.level}%</span>
                </div>
                <div className={`h-2 ${isDark ? 'bg-gray-700' : 'bg-gray-200'} rounded-full`}>
                  <motion.div
                    initial={{ width: 0 }}
                    animate={isVisible ? { width: `${skill.level}%` } : {}}
                    transition={{ duration: 1, delay: 0.8 + index * 0.1 }}
                    className="h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-full"
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}