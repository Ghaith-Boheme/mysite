import { useEffect, useRef } from 'react';

interface FloatingCodeProps {
  isDark: boolean;
}

const codeSnippets = [
  // أساسيات البرمجة
  "const x = 10;",
  "let data = [];",
  "var name = '';",
  "function init() {",
  "return true;",
  "class App {",
  "constructor() {",
  "super();",
  
  // React Hooks
  "useState(() => {",
  "useEffect(() => {",
  "useContext()",
  "useRef(null)",
  "useMemo(() =>",
  "useCallback(",
  
  // ES6+
  "async/await",
  "Promise.all([",
  "const { x, y }",
  "(...args) =>",
  "[...array]",
  
  // عربي
  "إذا (شرط) {",
  "دالة جديدة() {",
  "استيراد من",
  "تصدير إلى",
  "مصفوفة[]",
  
  // JSX/TSX
  "<Component>",
  "</Component>",
  "<div className=",
  "props.children",
  "{isLoading &&",
  
  // API/Database
  "fetch('/api')",
  "SELECT * FROM",
  "INSERT INTO",
  "UPDATE table",
  "DELETE FROM",
  
  // Testing
  "describe('",
  "test('it",
  "expect(x)",
  "toBe(true)",
  "mock()",
  
  // Git
  "git commit",
  "git push",
  "git merge",
  "git rebase",
  "git checkout",
  
  // NPM
  "npm install",
  "yarn add",
  "pnpm add",
  "package.json",
  "node_modules"
];

const symbols = [
  // Basic Operators
  "+", "-", "*", "/", "%",
  "++", "--", "+=", "-=",
  
  // Comparison
  "==", "===", "!=", "!==",
  ">", "<", ">=", "<=",
  
  // Logical
  "&&", "||", "??", "!",
  
  // Special
  "=>", "...", "::", "?.",
  
  // Brackets
  "{}", "[]", "()", "<>",
  "{{", "}}", "[[", "]]",
  
  // JSX
  "</>", "</", "/>", "{/*",
  
  // Math
  "π", "∑", "∞", "≈", "≠",
  "±", "÷", "×", "√", "∫",
  
  // Misc
  "@", "#", "$", "&", "|",
  "~", "^", "`", "\\", "•"
];

interface FloatingElement {
  content: string;
  x: number;
  y: number;
  rotation: number;
  scale: number;
  opacity: number;
  color: string;
  fontSize: string;
}

export const FloatingCode = ({ isDark }: FloatingCodeProps) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const elementsRef = useRef<FloatingElement[]>([]);

  const generateRandomColor = () => {
    if (isDark) {
      const hue = Math.random() * 360;
      return `hsl(${hue}, 70%, 70%)`;
    } else {
      // ألوان أغمق وأكثر تباينًا للوضع النهاري
      const hue = Math.random() * 360;
      return `hsl(${hue}, 70%, 40%)`;
    }
  };

  const createFloatingElement = (): FloatingElement => {
    const isSymbol = Math.random() > 0.7;
    const content = isSymbol 
      ? symbols[Math.floor(Math.random() * symbols.length)]
      : codeSnippets[Math.floor(Math.random() * codeSnippets.length)];

    // تحديد حجم الخط بشكل عشوائي
    const fontSize = isSymbol 
      ? `${Math.floor(14 + Math.random() * 10)}px`  // 14px - 24px للرموز
      : `${Math.floor(12 + Math.random() * 6)}px`;  // 12px - 18px للأكواد

    return {
      content,
      x: Math.random() * 100,
      y: 110,
      rotation: (Math.random() - 0.5) * 60,
      scale: 0.8 + Math.random() * 0.4,
      opacity: isDark ? (0.2 + Math.random() * 0.3) : (0.15 + Math.random() * 0.25),
      color: generateRandomColor(),
      fontSize
    };
  };

  useEffect(() => {
    if (!containerRef.current) return;

    const addNewElement = () => {
      const newElement = createFloatingElement();
      elementsRef.current.push(newElement);

      const element = document.createElement('div');
      element.className = 'absolute font-mono pointer-events-none';
      element.style.left = `${newElement.x}%`;
      element.style.top = `${newElement.y}%`;
      element.style.transform = `rotate(${newElement.rotation}deg) scale(${newElement.scale})`;
      element.style.opacity = newElement.opacity.toString();
      element.style.color = newElement.color;
      element.style.fontSize = newElement.fontSize;
      element.style.textShadow = isDark ? '0 0 5px currentColor' : '0 0 2px currentColor';
      element.innerText = newElement.content;
      
      containerRef.current?.appendChild(element);

      const duration = 10000 + Math.random() * 5000; // 10-15 seconds
      const keyframes = [
        { 
          transform: `rotate(${newElement.rotation}deg) scale(${newElement.scale})`,
          top: '110%',
          opacity: newElement.opacity
        },
        { 
          transform: `rotate(${newElement.rotation + (Math.random() - 0.5) * 120}deg) scale(${newElement.scale})`,
          top: '-10%',
          opacity: 0
        }
      ];
      
      const animation = element.animate(keyframes, {
        duration,
        easing: 'cubic-bezier(0.4, 0, 0.2, 1)',
      });

      animation.onfinish = () => {
        element.remove();
        elementsRef.current = elementsRef.current.filter(el => el !== newElement);
      };
    };

    // إضافة عناصر بشكل متكرر
    const interval = setInterval(addNewElement, 300); // كل 300 مللي ثانية
    
    // إضافة عدة عناصر في البداية
    for (let i = 0; i < 20; i++) {
      setTimeout(() => addNewElement(), i * 100);
    }

    return () => clearInterval(interval);
  }, [isDark]);

  return (
    <div 
      ref={containerRef} 
      className="fixed inset-0 overflow-hidden pointer-events-none z-0"
      style={{ opacity: isDark ? 0.5 : 0.3 }}
    />
  );
};