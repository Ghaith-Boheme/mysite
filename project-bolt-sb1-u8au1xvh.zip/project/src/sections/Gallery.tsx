import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Tag } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { FuturisticImageGallery } from '../components/FuturisticImageGallery';

interface GalleryProps {
  isRTL: boolean;
  isDark: boolean;
}

interface GalleryImage {
  id: number;
  src: string;
  alt: string;
  category: string;
  description: string;
}

export default function Gallery({ isRTL, isDark }: GalleryProps) {
  const { elementRef, isVisible } = useIntersectionObserver();
  const [activeCategory, setActiveCategory] = useState<string>('all');

  const images: GalleryImage[] = [
    {
      id: 1,
      src: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=800&q=80',
      alt: isRTL ? 'تطوير الويب' : 'Web Development',
      category: 'work',
      description: isRTL ? 'العمل على مشروع تطوير الويب باستخدام React و TypeScript' : 'Working on a web development project using React and TypeScript'
    },
    {
      id: 2,
      src: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80',
      alt: isRTL ? 'البرمجة' : 'Coding',
      category: 'work',
      description: isRTL ? 'كتابة الكود لتطبيق ويب تفاعلي' : 'Writing code for an interactive web application'
    },
    {
      id: 3,
      src: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=800&q=80',
      alt: isRTL ? 'اجتماع الفريق' : 'Team Meeting',
      category: 'work',
      description: isRTL ? 'اجتماع مع فريق المطورين لمناقشة المشروع' : 'Meeting with the development team to discuss the project'
    },
    {
      id: 4,
      src: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80',
      alt: isRTL ? 'مؤتمر تقني' : 'Tech Conference',
      category: 'events',
      description: isRTL ? 'حضور مؤتمر تقني للتعرف على أحدث التقنيات' : 'Attending a tech conference to learn about the latest technologies'
    },
    {
      id: 5,
      src: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=800&q=80',
      alt: isRTL ? 'العمل عن بعد' : 'Remote Work',
      category: 'work',
      description: isRTL ? 'العمل عن بعد من المنزل على مشروع برمجي' : 'Working remotely from home on a programming project'
    },
    {
      id: 6,
      src: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=800&q=80',
      alt: isRTL ? 'ورشة عمل' : 'Workshop',
      category: 'events',
      description: isRTL ? 'تقديم ورشة عمل حول تطوير الواجهات الأمامية' : 'Conducting a workshop on frontend development'
    },
    {
      id: 7,
      src: 'https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?auto=format&fit=crop&w=800&q=80',
      alt: isRTL ? 'مساحة العمل' : 'Workspace',
      category: 'personal',
      description: isRTL ? 'مساحة العمل الخاصة بي مع أجهزة الكمبيوتر المتعددة' : 'My workspace with multiple computer setups'
    },
    {
      id: 8,
      src: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=800&q=80',
      alt: isRTL ? 'رحلة استكشافية' : 'Exploration Trip',
      category: 'personal',
      description: isRTL ? 'رحلة استكشافية للحصول على الإلهام للمشاريع الجديدة' : 'Exploration trip to get inspiration for new projects'
    },
    {
      id: 9,
      src: 'https://images.unsplash.com/photo-1581291518633-83b4ebd1d83e?auto=format&fit=crop&w=800&q=80',
      alt: isRTL ? 'تصميم المواقع' : 'Web Design',
      category: 'work',
      description: isRTL ? 'العمل على تصميم موقع ويب جديد باستخدام Figma' : 'Working on a new website design using Figma'
    }
  ];

  const categories = [
    { id: 'all', name: isRTL ? 'الكل' : 'All' },
    { id: 'work', name: isRTL ? 'العمل' : 'Work' },
    { id: 'events', name: isRTL ? 'الفعاليات' : 'Events' },
    { id: 'personal', name: isRTL ? 'شخصي' : 'Personal' }
  ];

  const filteredImages = activeCategory === 'all' 
    ? images 
    : images.filter(image => image.category === activeCategory);

  // Enhanced colors for light mode
  const textColor = isDark ? 'text-white' : 'text-gray-800';
  const textColorSecondary = isDark ? 'text-gray-300' : 'text-gray-700';
  const buttonBgActive = isDark ? 'bg-blue-600' : 'bg-indigo-600';
  const buttonBgInactive = isDark ? 'bg-gray-700' : 'bg-gray-100';

  return (
    <div ref={elementRef} className="min-h-screen py-16 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-blue-500 to-purple-600 text-transparent bg-clip-text text-center"
        >
          {isRTL ? 'معرض الصور' : 'Photo Gallery'}
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className={`text-center mb-12 max-w-3xl mx-auto ${textColorSecondary}`}
        >
          {isRTL 
            ? 'مجموعة من الصور التي تعرض رحلتي المهنية والشخصية في مجال تطوير البرمجيات'
            : 'A collection of photos showcasing my professional and personal journey in software development'}
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="flex flex-wrap justify-center gap-3 mb-8"
        >
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`px-4 py-2 rounded-full transition-all ${
                activeCategory === category.id
                  ? `${buttonBgActive} text-white font-medium`
                  : `${buttonBgInactive} ${textColor} hover:opacity-80`
              }`}
            >
              {category.name}
            </button>
          ))}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          <FuturisticImageGallery 
            images={filteredImages.map(img => ({
              id: img.id,
              src: img.src,
              alt: img.alt,
              description: img.description
            }))} 
            isDark={isDark} 
            isRTL={isRTL} 
          />
        </motion.div>
      </div>
    </div>
  );
}