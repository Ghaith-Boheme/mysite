import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Tag, User, Clock, ChevronRight } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

interface NewsProps {
  isRTL: boolean;
  isDark: boolean;
}

export default function News({ isRTL, isDark }: NewsProps) {
  const { elementRef, isVisible } = useIntersectionObserver();
  
  const newsItems = [
    {
      id: 1,
      title: isRTL ? 'إطلاق مشروع جديد' : 'New Project Launch',
      excerpt: isRTL 
        ? 'تم إطلاق مشروع جديد للتجارة الإلكترونية مع واجهة مستخدم متطورة وتقنيات حديثة.'
        : 'Launched a new e-commerce project with advanced UI and modern technologies.',
      date: '2025-03-15',
      author: isRTL ? 'أحمد محمد' : 'Ahmed Mohamed',
      category: isRTL ? 'مشاريع' : 'Projects',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80',
      readTime: 5
    },
    {
      id: 2,
      title: isRTL ? 'مؤتمر التكنولوجيا السنوي' : 'Annual Tech Conference',
      excerpt: isRTL 
        ? 'حضرت مؤتمر التكنولوجيا السنوي وشاركت في ورشة عمل حول تطوير الواجهات الأمامية.'
        : 'Attended the annual tech conference and participated in a workshop on frontend development.',
      date: '2025-02-28',
      author: isRTL ? 'سارة أحمد' : 'Sara Ahmed',
      category: isRTL ? 'فعاليات' : 'Events',
      image: 'https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=800&q=80',
      readTime: 3
    },
    {
      id: 3,
      title: isRTL ? 'تعلم تقنية جديدة' : 'Learning a New Technology',
      excerpt: isRTL 
        ? 'بدأت في تعلم تقنية جديدة لتطوير تطبيقات الويب التفاعلية باستخدام WebAssembly.'
        : 'Started learning a new technology for developing interactive web applications using WebAssembly.',
      date: '2025-01-10',
      author: isRTL ? 'محمد علي' : 'Mohamed Ali',
      category: isRTL ? 'تعلم' : 'Learning',
      image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=800&q=80',
      readTime: 7
    }
  ];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat(isRTL ? 'ar-EG' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    }).format(date);
  };

  // Enhanced colors for light mode
  const textColor = isDark ? 'text-white' : 'text-gray-800';
  const textColorSecondary = isDark ? 'text-gray-300' : 'text-gray-700';
  const cardBg = isDark ? 'bg-gray-800 bg-opacity-50' : 'bg-white shadow-md';
  const hoverBg = isDark ? 'hover:bg-gray-700' : 'hover:bg-indigo-50';
  const categoryColor = isDark ? 'text-blue-500' : 'text-indigo-600';
  const metaColor = isDark ? 'text-gray-400' : 'text-gray-500';
  const buttonColor = isDark ? textColor : 'text-indigo-600';

  return (
    <div ref={elementRef} className="min-h-screen py-16 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-blue-500 to-purple-600 text-transparent bg-clip-text text-center tracking-tight"
        >
          {isRTL ? 'آخر الأخبار' : 'Latest News'}
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className={`text-center mb-12 max-w-3xl mx-auto ${textColorSecondary} text-lg font-light leading-relaxed`}
        >
          {isRTL 
            ? 'اطلع على آخر الأخبار والتحديثات حول مشاريعي والتقنيات التي أعمل عليها'
            : 'Stay updated with the latest news and updates about my projects and technologies I work with'}
        </motion.p>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {newsItems.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.3 + index * 0.1 }}
              className={`${cardBg} rounded-xl overflow-hidden ${isDark ? '' : 'border border-gray-100'} transform transition-all duration-300 hover:scale-105 hover:shadow-xl`}
            >
              <img
                src={item.image}
                alt={item.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center mb-3">
                  <Tag className={`w-4 h-4 ${categoryColor} mr-2`} />
                  <span className={`text-xs ${categoryColor} font-semibold uppercase tracking-wider`}>{item.category}</span>
                </div>
                <h2 className={`text-xl font-bold mb-3 ${textColor} tracking-tight leading-tight`}>{item.title}</h2>
                <p className={`mb-4 ${textColorSecondary} text-sm leading-relaxed`}>{item.excerpt}</p>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center">
                    <Calendar className={`w-4 h-4 ${metaColor} mr-1`} />
                    <span className={`text-xs ${metaColor}`}>{formatDate(item.date)}</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className={`w-4 h-4 ${metaColor} mr-1`} />
                    <span className={`text-xs ${metaColor}`}>{item.readTime} {isRTL ? 'دقائق' : 'min read'}</span>
                  </div>
                </div>
                <div className="flex items-center">
                  <User className={`w-4 h-4 ${metaColor} mr-2`} />
                  <span className={`text-xs ${metaColor}`}>{item.author}</span>
                </div>
                <button className={`mt-4 w-full py-2 rounded-lg flex items-center justify-center ${hoverBg} transition-colors ${buttonColor} text-sm font-medium`}>
                  {isRTL ? 'قراءة المزيد' : 'Read More'} 
                  <ChevronRight className="w-4 h-4 ml-1" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}