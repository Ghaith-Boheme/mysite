import React from 'react';
import { motion } from 'framer-motion';
import { ArrowDown } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';
import { FuturisticProfile } from '../components/FuturisticProfile';

interface HomeProps {
  isRTL: boolean;
  isDark: boolean;
}

export default function Home({ isRTL, isDark }: HomeProps) {
  const { elementRef, isVisible } = useIntersectionObserver();

  // Text color for better visibility in light mode
  const textColor = isDark ? 'text-gray-300' : 'text-gray-700';
  
  // Scroll to About section
  const scrollToAbout = () => {
    const aboutSection = document.querySelector('section:nth-child(2)');
    if (aboutSection) {
      aboutSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div ref={elementRef} className="relative min-h-screen flex flex-col items-center justify-center px-4 py-16">
      <div className="max-w-4xl mx-auto text-center">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-transparent bg-clip-text tracking-tight leading-tighter"
        >
          {isRTL ? 'مرحباً! أنا غيث بوهيمي' : 'Hello! I am Ghaith Boheme'}
        </motion.h1>
        
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={isVisible ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="my-8"
        >
          <FuturisticProfile isRTL={isRTL} isDark={isDark} />
        </motion.div>
        
        <motion.p 
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
          className={`text-xl md:text-2xl ${textColor} mb-8 font-light leading-relaxed`}
        >
          {isRTL 
            ? 'أجد الحلول للمشاكل باستخدام أدوات التكنولوجيا الحديثة، مع الاستفادة من الآلة الكبيرة التي تسمى الذكاء الاصطناعي. أعمل على ابتكار حلول عملية تسهم في تحسين الأداء وتسهيل الحياة اليومية. أركز على أتمتة المهام، تطوير صفحات الويب، وتقديم الدعم الفني الفعّال لتلبية احتياجات الأفراد والشركات. كل مشروع بالنسبة لي هو فرصة لتطبيق حلول مبتكرة، مما يساهم في تحسين تجربة المستخدم وزيادة الإنتاجية.'
            : "I find solutions to problems by leveraging modern technology tools, with the help of the great machine known as artificial intelligence. I focus on creating practical solutions that enhance performance and simplify daily tasks. My work includes automating processes, developing web pages, and providing effective technical support to meet the needs of individuals and businesses. Each project is an opportunity to apply innovative solutions, improving user experience and boosting productivity."
          }
        </motion.p>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="flex flex-col items-center"
        >
          <motion.button
            onClick={scrollToAbout}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
            className={`mt-8 p-3 rounded-full ${isDark ? 'bg-gray-800 hover:bg-gray-700' : 'bg-indigo-100 hover:bg-indigo-200'} transition-colors`}
            aria-label={isRTL ? 'انتقل إلى القسم التالي' : 'Scroll to next section'}
          >
            <ArrowDown className={`w-8 h-8 ${isDark ? 'text-blue-400' : 'text-blue-600'}`} />
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
}