import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Github } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

interface ProjectsProps {
  isRTL: boolean;
  isDark: boolean;
}

export default function Projects({ isRTL, isDark }: ProjectsProps) {
  const { elementRef, isVisible } = useIntersectionObserver();
  
  const projects = [
    {
      title: isRTL ? 'تطبيق إدارة المهام' : 'Task Management App',
      description: isRTL
        ? 'تطبيق ويب تفاعلي لإدارة المهام والمشاريع مع دعم للفرق'
        : 'Interactive web application for managing tasks and projects with team support',
      image: 'https://images.unsplash.com/photo-1507925921958-8a62f3d1a50d?auto=format&fit=crop&w=800&q=80',
      tech: ['React', 'Node.js', 'PostgreSQL'],
      github: 'https://github.com',
      demo: 'https://demo.com'
    },
    {
      title: isRTL ? 'منصة التعلم الإلكتروني' : 'E-Learning Platform',
      description: isRTL
        ? 'منصة تعليمية متكاملة مع دعم للدورات التدريبية والاختبارات'
        : 'Comprehensive learning platform with support for courses and assessments',
      image: 'https://images.unsplash.com/photo-1501504905252-473c47e087f8?auto=format&fit=crop&w=800&q=80',
      tech: ['Vue.js', 'Django', 'MongoDB'],
      github: 'https://github.com',
      demo: 'https://demo.com'
    },
    {
      title: isRTL ? 'تطبيق التحليلات' : 'Analytics Dashboard',
      description: isRTL
        ? 'لوحة تحكم تحليلية متقدمة مع رسوم بيانية تفاعلية'
        : 'Advanced analytics dashboard with interactive charts',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80',
      tech: ['React', 'D3.js', 'Firebase'],
      github: 'https://github.com',
      demo: 'https://demo.com'
    }
  ];

  // Enhanced colors for light mode
  const textColor = isDark ? 'text-white' : 'text-gray-800';
  const textColorSecondary = isDark ? 'text-gray-400' : 'text-gray-600';
  const cardBg = isDark ? 'bg-gray-800 bg-opacity-50' : 'bg-white shadow-md';
  const techBadgeBg = isDark ? 'bg-gray-700' : 'bg-gray-100';
  const techBadgeText = isDark ? 'text-gray-300' : 'text-gray-700';
  const linkColorGithub = isDark ? 'text-gray-300 hover:text-white' : 'text-gray-600 hover:text-gray-900';
  const linkColorDemo = isDark ? 'text-blue-400 hover:text-blue-300' : 'text-indigo-600 hover:text-indigo-800';

  return (
    <div ref={elementRef} className="min-h-screen py-16 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-blue-500 to-purple-600 text-transparent bg-clip-text text-center tracking-tight"
        >
          {isRTL ? 'مشاريعي' : 'My Projects'}
        </motion.h1>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 20 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.1 }}
              className={`${cardBg} rounded-xl overflow-hidden ${isDark ? '' : 'border border-gray-100'} transform hover:scale-105 transition-transform duration-300`}
            >
              <img
                src={project.image}
                alt={project.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <h2 className={`text-xl font-semibold ${textColor} mb-2 tracking-tight`}>{project.title}</h2>
                <p className={`${textColorSecondary} mb-4 text-sm leading-relaxed`}>{project.description}</p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {project.tech.map(tech => (
                    <span
                      key={tech}
                      className={`px-3 py-1 ${techBadgeBg} rounded-full text-xs font-medium ${techBadgeText}`}
                    >
                      {tech}
                    </span>
                  ))}
                </div>
                <div className="flex space-x-4 rtl:space-x-reverse">
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex items-center ${linkColorGithub} transition-colors text-sm font-medium`}
                  >
                    <Github className="w-5 h-5 mr-1" />
                    GitHub
                  </a>
                  <a
                    href={project.demo}
                    target="_blank"
                    rel="noopener noreferrer"
                    className={`flex items-center ${linkColorDemo} transition-colors text-sm font-medium`}
                  >
                    <ExternalLink className="w-5 h-5 mr-1" />
                    Demo
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}