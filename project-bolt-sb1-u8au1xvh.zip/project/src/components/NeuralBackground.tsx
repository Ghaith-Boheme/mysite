import { useEffect, useRef } from 'react';

interface NeuralBackgroundProps {
  isDark: boolean;
}

export const NeuralBackground = ({ isDark }: NeuralBackgroundProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  const pointsRef = useRef<Point[]>([]);
  const rafRef = useRef<number>();

  interface Point {
    x: number;
    y: number;
    vx: number;
    vy: number;
    connections: number[];
  }

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const handleResize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      initPoints();
    };

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = { x: e.clientX, y: e.clientY };
    };

    const initPoints = () => {
      const points: Point[] = Array.from({ length: 50 }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
        connections: []
      }));

      points.forEach((point, i) => {
        for (let j = i + 1; j < points.length; j++) {
          if (Math.random() > 0.7) {
            point.connections.push(j);
          }
        }
      });

      pointsRef.current = points;
    };

    const drawConnection = (
      ctx: CanvasRenderingContext2D,
      x1: number,
      y1: number,
      x2: number,
      y2: number,
      alpha: number
    ) => {
      const gradient = ctx.createLinearGradient(x1, y1, x2, y2);
      if (isDark) {
        gradient.addColorStop(0, `rgba(64, 196, 255, ${alpha})`);
        gradient.addColorStop(1, `rgba(128, 64, 255, ${alpha})`);
      } else {
        gradient.addColorStop(0, `rgba(37, 99, 235, ${alpha * 0.6})`);
        gradient.addColorStop(1, `rgba(79, 70, 229, ${alpha * 0.6})`);
      }
      
      ctx.beginPath();
      ctx.strokeStyle = gradient;
      ctx.lineWidth = isDark ? 0.5 : 0.8;
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.stroke();
    };

    const animate = () => {
      ctx.fillStyle = isDark 
        ? 'rgba(0, 0, 0, 0.1)' 
        : 'rgba(255, 255, 255, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      pointsRef.current.forEach((point, i) => {
        point.x += point.vx;
        point.y += point.vy;

        if (point.x < 0 || point.x > canvas.width) point.vx *= -1;
        if (point.y < 0 || point.y > canvas.height) point.vy *= -1;

        const mouseDist = Math.hypot(point.x - mouseRef.current.x, point.y - mouseRef.current.y);
        if (mouseDist < 200) {
          const angle = Math.atan2(mouseRef.current.y - point.y, mouseRef.current.x - point.x);
          point.vx += Math.cos(angle) * 0.05;
          point.vy += Math.sin(angle) * 0.05;
        }

        point.vx *= 0.99;
        point.vy *= 0.99;

        point.connections.forEach(j => {
          const otherPoint = pointsRef.current[j];
          const dist = Math.hypot(point.x - otherPoint.x, point.y - otherPoint.y);
          if (dist < 150) {
            drawConnection(
              ctx,
              point.x,
              point.y,
              otherPoint.x,
              otherPoint.y,
              1 - dist / 150
            );
          }
        });

        ctx.beginPath();
        ctx.arc(point.x, point.y, isDark ? 2 : 2.5, 0, Math.PI * 2);
        ctx.fillStyle = isDark 
          ? 'rgba(64, 196, 255, 0.5)'
          : 'rgba(79, 70, 229, 0.5)';
        ctx.fill();
      });

      rafRef.current = requestAnimationFrame(animate);
    };

    window.addEventListener('resize', handleResize);
    window.addEventListener('mousemove', handleMouseMove);
    handleResize();
    animate();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, [isDark]);

  return (
    <canvas
      ref={canvasRef}
      className={`fixed inset-0 pointer-events-none z-0 ${isDark ? 'bg-black' : 'bg-gray-50'}`}
    />
  );
};