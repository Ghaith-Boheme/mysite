import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { HolographicFrame } from './HolographicFrame';
import { Maximize2, X, ChevronLeft, ChevronRight, Scan, Zap } from 'lucide-react';

interface FuturisticImageGalleryProps {
  images: Array<{
    id: number;
    src: string;
    alt: string;
    description?: string;
  }>;
  isDark: boolean;
  isRTL: boolean;
}

export const FuturisticImageGallery: React.FC<FuturisticImageGalleryProps> = ({ 
  images, 
  isDark, 
  isRTL 
}) => {
  const [selectedImage, setSelectedImage] = useState<number | null>(null);
  const [hoveredImage, setHoveredImage] = useState<number | null>(null);
  
  const openImage = (id: number) => {
    setSelectedImage(id);
    document.body.style.overflow = 'hidden';
  };
  
  const closeImage = () => {
    setSelectedImage(null);
    document.body.style.overflow = 'auto';
  };
  
  const navigateImage = (direction: 'next' | 'prev') => {
    if (selectedImage === null) return;
    
    const currentIndex = images.findIndex(img => img.id === selectedImage);
    let newIndex;
    
    if (direction === 'next') {
      newIndex = (currentIndex + 1) % images.length;
    } else {
      newIndex = (currentIndex - 1 + images.length) % images.length;
    }
    
    setSelectedImage(images[newIndex].id);
  };
  
  // Colors based on theme
  const textColor = isDark ? 'text-white' : 'text-gray-800';
  const textColorSecondary = isDark ? 'text-gray-300' : 'text-gray-600';
  const accentColor = isDark ? 'text-cyan-400' : 'text-indigo-600';
  const bgColor = isDark ? 'bg-gray-900/90' : 'bg-gray-100/90';
  const buttonBg = isDark ? 'bg-gray-800' : 'bg-white';
  
  return (
    <div className="w-full">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {images.map((image) => (
          <motion.div
            key={image.id}
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.98 }}
            onHoverStart={() => setHoveredImage(image.id)}
            onHoverEnd={() => setHoveredImage(null)}
            onClick={() => openImage(image.id)}
            className="cursor-pointer"
          >
            <HolographicFrame 
              isDark={isDark} 
              isActive={hoveredImage === image.id}
              className="aspect-[4/3] overflow-hidden"
            >
              <div className="relative w-full h-full">
                <img 
                  src={image.src} 
                  alt={image.alt}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                />
                
                {/* Futuristic overlay */}
                <div className={`absolute inset-0 bg-gradient-to-t ${
                  isDark 
                    ? 'from-cyan-900/20 via-transparent to-purple-900/20' 
                    : 'from-indigo-500/10 via-transparent to-purple-500/10'
                } mix-blend-overlay`} />
                
                {/* Hover UI elements */}
                <AnimatePresence>
                  {hoveredImage === image.id && (
                    <>
                      {/* Top left */}
                      <motion.div
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ duration: 0.3 }}
                        className="absolute top-3 left-3 flex items-center"
                      >
                        <Scan className={`w-4 h-4 ${accentColor} mr-1`} />
                        <span className={`text-xs font-mono ${accentColor}`}>ID.{image.id.toString().padStart(4, '0')}</span>
                      </motion.div>
                      
                      {/* Bottom */}
                      <motion.div
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 20 }}
                        transition={{ duration: 0.3 }}
                        className={`absolute bottom-0 left-0 right-0 p-3 ${isDark ? 'bg-black/50' : 'bg-white/50'} backdrop-blur-sm`}
                      >
                        <h3 className={`text-sm font-bold ${textColor}`}>{image.alt}</h3>
                        {image.description && (
                          <p className={`text-xs ${textColorSecondary} mt-1 line-clamp-1`}>{image.description}</p>
                        )}
                      </motion.div>
                      
                      {/* Center icon */}
                      <motion.div
                        initial={{ opacity: 0, scale: 0.5 }}
                        animate={{ opacity: 0.8, scale: 1 }}
                        exit={{ opacity: 0, scale: 0.5 }}
                        transition={{ duration: 0.3 }}
                        className="absolute inset-0 flex items-center justify-center"
                      >
                        <div className={`p-3 rounded-full ${isDark ? 'bg-black/30' : 'bg-white/30'} backdrop-blur-sm`}>
                          <Maximize2 className={`w-6 h-6 ${accentColor}`} />
                        </div>
                      </motion.div>
                    </>
                  )}
                </AnimatePresence>
              </div>
            </HolographicFrame>
          </motion.div>
        ))}
      </div>
      
      {/* Fullscreen view */}
      <AnimatePresence>
        {selectedImage !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className={`fixed inset-0 ${bgColor} backdrop-blur-md z-50 flex items-center justify-center p-4`}
          >
            <button
              onClick={closeImage}
              className={`absolute top-4 right-4 p-2 rounded-full ${buttonBg} ${textColor} hover:${accentColor} z-10`}
              aria-label="Close"
            >
              <X className="w-6 h-6" />
            </button>
            
            <button
              onClick={() => navigateImage('prev')}
              className={`absolute left-4 p-2 rounded-full ${buttonBg} ${textColor} hover:${accentColor} z-10`}
              aria-label="Previous"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            
            <button
              onClick={() => navigateImage('next')}
              className={`absolute right-4 p-2 rounded-full ${buttonBg} ${textColor} hover:${accentColor} z-10`}
              aria-label="Next"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
            
            {selectedImage !== null && (
              <div className="max-w-4xl w-full">
                <HolographicFrame isDark={isDark} className="w-full">
                  <div className="relative">
                    <img
                      src={images.find(img => img.id === selectedImage)?.src}
                      alt={images.find(img => img.id === selectedImage)?.alt || ''}
                      className="w-full max-h-[70vh] object-contain"
                    />
                    
                    {/* Image info */}
                    <div className={`p-4 ${isDark ? 'bg-gray-800/80' : 'bg-white/80'} backdrop-blur-sm`}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center">
                          <Scan className={`w-4 h-4 ${accentColor} mr-2`} />
                          <span className={`text-xs font-mono ${accentColor}`}>
                            ID.{selectedImage.toString().padStart(4, '0')}
                          </span>
                        </div>
                        <div className="flex items-center">
                          <Zap className={`w-4 h-4 ${accentColor} mr-1`} />
                          <span className={`text-xs font-mono ${accentColor}`}>RESOLUTION ENHANCED</span>
                        </div>
                      </div>
                      
                      <h3 className={`text-xl font-bold ${textColor}`}>
                        {images.find(img => img.id === selectedImage)?.alt}
                      </h3>
                      
                      {images.find(img => img.id === selectedImage)?.description && (
                        <p className={`mt-2 ${textColorSecondary}`}>
                          {images.find(img => img.id === selectedImage)?.description}
                        </p>
                      )}
                    </div>
                  </div>
                </HolographicFrame>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};