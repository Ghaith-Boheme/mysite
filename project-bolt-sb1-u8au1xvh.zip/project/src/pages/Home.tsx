import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PageTransition } from '../components/PageTransition';

interface HomeProps {
  isRTL: boolean;
}

export default function Home({ isRTL }: HomeProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        duration: 0.5,
        delayChildren: 0.2,
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <PageTransition>
      <div className="relative min-h-[calc(100vh-4rem)] flex items-center justify-center px-4">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="max-w-4xl mx-auto text-center"
        >
          <motion.h1 
            variants={itemVariants}
            className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-transparent bg-clip-text"
          >
            {isRTL ? 'مرحباً بك في معرضي' : 'Welcome to My Portfolio'}
          </motion.h1>
          
          <motion.p 
            variants={itemVariants}
            className="text-xl md:text-2xl text-gray-300 mb-8"
          >
            {isRTL 
              ? 'مطور برمجيات متخصص في بناء تطبيقات ويب حديثة وتفاعلية'
              : 'A software developer specialized in building modern, interactive web applications'}
          </motion.p>
          
          <motion.div
            variants={itemVariants}
            className="flex justify-center space-x-4 rtl:space-x-reverse"
          >
            <Link
              to="/projects"
              className="inline-flex items-center px-6 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white transition-all transform hover:scale-105"
            >
              {isRTL ? (
                <>
                  عرض المشاريع
                  <ArrowLeft className="rtl:mr-2 ltr:ml-2 w-5 h-5" />
                </>
              ) : (
                <>
                  View Projects
                  <ArrowRight className="rtl:mr-2 ltr:ml-2 w-5 h-5" />
                </>
              )}
            </Link>
          </motion.div>
        </motion.div>
      </div>
    </PageTransition>
  );
}