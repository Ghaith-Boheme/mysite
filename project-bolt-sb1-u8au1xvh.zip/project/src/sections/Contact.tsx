import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send } from 'lucide-react';
import { useIntersectionObserver } from '../hooks/useIntersectionObserver';

interface ContactProps {
  isRTL: boolean;
  isDark: boolean;
}

export default function Contact({ isRTL, isDark }: ContactProps) {
  const { elementRef, isVisible } = useIntersectionObserver();
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  // Enhanced colors for light mode
  const textColor = isDark ? 'text-white' : 'text-gray-800';
  const textColorSecondary = isDark ? 'text-gray-300' : 'text-gray-600';
  const cardBg = isDark ? 'bg-gray-800 bg-opacity-50' : 'bg-white shadow-md';
  const inputBg = isDark ? 'bg-gray-700' : 'bg-gray-50';
  const inputBorder = isDark ? 'border-gray-600' : 'border-gray-300';
  const inputText = isDark ? 'text-white' : 'text-gray-800';
  const iconColors = {
    blue: isDark ? 'text-blue-400' : 'text-blue-600',
    green: isDark ? 'text-green-400' : 'text-green-600',
    red: isDark ? 'text-red-400' : 'text-red-600'
  };

  return (
    <div ref={elementRef} className="min-h-screen py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-blue-500 to-purple-600 text-transparent bg-clip-text text-center"
        >
          {isRTL ? 'اتصل بي' : 'Contact Me'}
        </motion.h1>

        <div className="grid md:grid-cols-2 gap-8">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={isVisible ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <div className={`${cardBg} rounded-xl p-6`}>
              <h2 className={`text-2xl font-semibold ${textColor} mb-6`}>
                {isRTL ? 'معلومات التواصل' : 'Contact Information'}
              </h2>
              <div className="space-y-4">
                <div className={`flex items-center ${textColorSecondary}`}>
                  <Mail className={`w-5 h-5 mr-3 ${iconColors.blue}`} />
                  <span>contact@example.com</span>
                </div>
                <div className={`flex items-center ${textColorSecondary}`}>
                  <Phone className={`w-5 h-5 mr-3 ${iconColors.green}`} />
                  <span>+1 234 567 890</span>
                </div>
                <div className={`flex items-center ${textColorSecondary}`}>
                  <MapPin className={`w-5 h-5 mr-3 ${iconColors.red}`} />
                  <span>New York, NY</span>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={isVisible ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            <form onSubmit={handleSubmit} className={`${cardBg} rounded-xl p-6`}>
              <div className="space-y-4">
                <div>
                  <label htmlFor="name" className={`block text-sm font-medium ${textColorSecondary} mb-1`}>
                    {isRTL ? 'الاسم' : 'Name'}
                  </label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className={`w-full px-4 py-2 ${inputBg} border ${inputBorder} rounded-lg focus:outline-none focus:border-blue-500 ${inputText}`}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="email" className={`block text-sm font-medium ${textColorSecondary} mb-1`}>
                    {isRTL ? 'البريد الإلكتروني' : 'Email'}
                  </label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className={`w-full px-4 py-2 ${inputBg} border ${inputBorder} rounded-lg focus:outline-none focus:border-blue-500 ${inputText}`}
                    required
                  />
                </div>
                <div>
                  <label htmlFor="message" className={`block text-sm font-medium ${textColorSecondary} mb-1`}>
                    {isRTL ? 'الرسالة' : 'Message'}
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    rows={4}
                    className={`w-full px-4 py-2 ${inputBg} border ${inputBorder} rounded-lg focus:outline-none focus:border-blue-500 ${inputText}`}
                    required
                  />
                </div>
                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-6 py-3 rounded-lg flex items-center justify-center transition-all transform hover:scale-105"
                >
                  <Send className="w-5 h-5 mr-2" />
                  {isRTL ? 'إرسال الرسالة' : 'Send Message'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      </div>
    </div>
  );
}