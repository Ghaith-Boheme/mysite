import React, { useEffect, useRef } from 'react';

interface HolographicFrameProps {
  children: React.ReactNode;
  isDark: boolean;
  isActive?: boolean;
  className?: string;
}

export const HolographicFrame: React.FC<HolographicFrameProps> = ({ 
  children, 
  isDark, 
  isActive = true,
  className = ""
}) => {
  const frameRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  // Create holographic edge effect
  useEffect(() => {
    if (!canvasRef.current || !frameRef.current || !isActive) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const updateCanvasSize = () => {
      if (frameRef.current) {
        const { width, height } = frameRef.current.getBoundingClientRect();
        canvas.width = width;
        canvas.height = height;
      }
    };
    
    updateCanvasSize();
    window.addEventListener('resize', updateCanvasSize);
    
    let angle = 0;
    let animationFrame: number;
    
    const draw = () => {
      if (!ctx) return;
      
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Draw holographic border
      const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
      
      // Shift hue based on angle
      const baseHue = isDark ? 180 : 230; // Cyan for dark mode, blue for light mode
      const hue1 = (baseHue + angle * 20) % 360;
      const hue2 = (baseHue + 120 + angle * 20) % 360;
      
      gradient.addColorStop(0, `hsla(${hue1}, 100%, 70%, 0.5)`);
      gradient.addColorStop(0.5, `hsla(${hue2}, 100%, 70%, 0.2)`);
      gradient.addColorStop(1, `hsla(${hue1}, 100%, 70%, 0.5)`);
      
      ctx.strokeStyle = gradient;
      ctx.lineWidth = 2;
      
      // Draw rounded rectangle
      const radius = 12; // Border radius
      const width = canvas.width;
      const height = canvas.height;
      
      ctx.beginPath();
      ctx.moveTo(radius, 0);
      ctx.lineTo(width - radius, 0);
      ctx.quadraticCurveTo(width, 0, width, radius);
      ctx.lineTo(width, height - radius);
      ctx.quadraticCurveTo(width, height, width - radius, height);
      ctx.lineTo(radius, height);
      ctx.quadraticCurveTo(0, height, 0, height - radius);
      ctx.lineTo(0, radius);
      ctx.quadraticCurveTo(0, 0, radius, 0);
      ctx.closePath();
      ctx.stroke();
      
      // Animate angle
      angle += 0.01;
      if (angle > Math.PI * 2) {
        angle = 0;
      }
      
      animationFrame = requestAnimationFrame(draw);
    };
    
    draw();
    
    return () => {
      window.removeEventListener('resize', updateCanvasSize);
      cancelAnimationFrame(animationFrame);
    };
  }, [isDark, isActive]);
  
  return (
    <div 
      ref={frameRef} 
      className={`relative rounded-xl overflow-hidden ${className}`}
      style={{
        boxShadow: isActive 
          ? isDark 
            ? '0 0 15px rgba(56, 189, 248, 0.3)' 
            : '0 0 15px rgba(79, 70, 229, 0.2)'
          : 'none',
        transition: 'box-shadow 0.5s ease'
      }}
    >
      {children}
      <canvas 
        ref={canvasRef} 
        className="absolute inset-0 pointer-events-none z-10"
        style={{ opacity: isActive ? 1 : 0, transition: 'opacity 0.5s ease' }}
      />
    </div>
  );
};