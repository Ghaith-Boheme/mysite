import React from 'react';
import { motion } from 'framer-motion';
import { Award, Book, Briefcase, Code } from 'lucide-react';

interface AboutProps {
  isRTL: boolean;
}

export default function About({ isRTL }: AboutProps) {
  const skills = [
    { name: 'React', level: 90 },
    { name: 'TypeScript', level: 85 },
    { name: 'Node.js', level: 80 },
    { name: 'Python', level: 75 },
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)] py-16 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-5xl font-bold mb-8 bg-gradient-to-r from-blue-500 to-purple-600 text-transparent bg-clip-text text-center"
        >
          {isRTL ? 'من أنا' : 'About Me'}
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="bg-gray-800 bg-opacity-50 rounded-xl p-6 mb-8"
        >
          <div className="flex items-center mb-4">
            <Book className="w-6 h-6 text-blue-400 mr-2" />
            <h2 className="text-2xl font-semibold text-white">
              {isRTL ? 'نبذة عني' : 'Bio'}
            </h2>
          </div>
          <p className="text-gray-300 leading-relaxed">
            {isRTL
              ? 'مطور برمجيات متحمس مع شغف كبير لبناء تطبيقات ويب حديثة وتفاعلية. أتمتع بخبرة واسعة في تطوير الواجهات الأمامية والخلفية، مع تركيز خاص على تقنيات JavaScript الحديثة.'
              : 'Passionate software developer with a strong drive for building modern and interactive web applications. Experienced in both frontend and backend development, with a particular focus on modern JavaScript technologies.'}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="grid md:grid-cols-2 gap-6 mb-8"
        >
          <div className="bg-gray-800 bg-opacity-50 rounded-xl p-6">
            <div className="flex items-center mb-4">
              <Briefcase className="w-6 h-6 text-purple-400 mr-2" />
              <h2 className="text-2xl font-semibold text-white">
                {isRTL ? 'الخبرة' : 'Experience'}
              </h2>
            </div>
            <ul className="space-y-4">
              <li>
                <h3 className="text-lg font-semibold text-white">Senior Developer</h3>
                <p className="text-gray-400">Tech Corp • 2020 - Present</p>
              </li>
              <li>
                <h3 className="text-lg font-semibold text-white">Full Stack Developer</h3>
                <p className="text-gray-400">Web Solutions • 2018 - 2020</p>
              </li>
            </ul>
          </div>

          <div className="bg-gray-800 bg-opacity-50 rounded-xl p-6">
            <div className="flex items-center mb-4">
              <Award className="w-6 h-6 text-yellow-400 mr-2" />
              <h2 className="text-2xl font-semibold text-white">
                {isRTL ? 'التعليم' : 'Education'}
              </h2>
            </div>
            <ul className="space-y-4">
              <li>
                <h3 className="text-lg font-semibold text-white">MSc Computer Science</h3>
                <p className="text-gray-400">Tech University • 2018</p>
              </li>
              <li>
                <h3 className="text-lg font-semibold text-white">BSc Computer Science</h3>
                <p className="text-gray-400">State University • 2016</p>
              </li>
            </ul>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="bg-gray-800 bg-opacity-50 rounded-xl p-6"
        >
          <div className="flex items-center mb-6">
            <Code className="w-6 h-6 text-green-400 mr-2" />
            <h2 className="text-2xl font-semibold text-white">
              {isRTL ? 'المهارات' : 'Skills'}
            </h2>
          </div>
          <div className="space-y-4">
            {skills.map((skill, index) => (
              <div key={skill.name}>
                <div className="flex justify-between mb-1">
                  <span className="text-white">{skill.name}</span>
                  <span className="text-gray-400">{skill.level}%</span>
                </div>
                <div className="h-2 bg-gray-700 rounded-full">
                  <motion.div
                    initial={{ width: 0 }}
                    animate={{ width: `${skill.level}%` }}
                    transition={{ duration: 1, delay: 0.8 + index * 0.1 }}
                    className="h-full bg-gradient-to-r from-blue-500 to-purple-600 rounded-full"
                  />
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}